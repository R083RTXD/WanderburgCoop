# WanderburgCoop

Experimenteller lokaler Positionstest für **Wanderburg**.

[English guide](README.md) · [Änderungen](CHANGELOG.md) · [MIT-Lizenz](LICENSE)

> **Entwicklungsstand 0.3.2 — noch kein spielbarer Koop-Mod.**
> Gegner, Schaden, Beute, XP, Upgrades und Welten laufen getrennt.
> Internet, LAN-Suche, Einladungscodes und Steam-Lobbys fehlen noch.
> Dieser Test-Mod blockiert die gefundenen Spielstand-Schreibmethoden.
> Test-Fortschritt wird nicht gespeichert. Für normale Runs den Mod entfernen.

Inoffizielles Community-Projekt von **R083RTXD**, ohne Verbindung zu oder
Unterstützungszusage von Randwerk bzw. dem Publisher. Das Repository enthält
unseren Mod-Code, keine Spieldateien, extrahierten Assets oder erzeugten
Spiel-Assemblies.

## Was funktioniert?

- Zwei Instanzen auf **demselben Windows-PC** verbinden sich per `127.0.0.1:28714`.
- Position und Drehrichtung der Burg werden bis zu 20-mal pro Sekunde übertragen.
- Die Gegenstelle erscheint als geglättete türkise Testfigur ohne Kollision.
- Netzwerkbetrieb auf einem eigenen Thread, unabhängig von Unity-Ladepausen.
- Fokusverlust pausiert den Run während einer aktiven lokalen Testsitzung nicht automatisch.
- **F8** gibt die Maus vorübergehend frei. Beim Klick zurück ins Spielfenster
  wird der vorherige Cursorzustand automatisch wiederhergestellt.
- Bewusstes Pausieren und Upgrade-Menüs bleiben erhalten.

## Voraussetzungen und Installation

Entwicklungsbasis: **Wanderburg 0.9.14b, Windows x64, Unity 6000.0.63f1**,
**BepInEx 6 IL2CPP x64**, getestet mit Loader `6.0.0-be.789`.
Andere Spielversionen sind ungeprüft. BepInEx 5 oder Mono funktioniert nicht.

1. Alle Spielinstanzen schließen und das Spielprofil sichern.
2. BepInEx gemäß der [offiziellen IL2CPP-Anleitung](https://docs.bepinex.dev/master/articles/user_guide/installation/unity_il2cpp.html)
   neben der eigentlichen Unity-EXE installieren: dort liegen auch `UnityPlayer.dll`
   und `GameAssembly.dll`. Nicht den äußeren Launcher-Ordner verwenden.
3. Spiel einmal starten, damit BepInEx die Interop-Dateien erzeugt.
4. Nur `WanderburgCoopTest.dll` nach `BepInEx/plugins/` kopieren.
5. Beide Instanzen neu starten. Das Fenster oben rechts muss **0.3.2** anzeigen.
6. Im `BepInEx/LogOutput.log` müssen die Ladermeldung und `TEST SAVE GUARD ACTIVE` stehen.

Wenn noch kein Download unter GitHub Releases bereitsteht, muss die DLL lokal
gebaut werden. Das Quellcode-ZIP allein installiert keinen Mod. BepInEx und das
Spiel werden nicht mitgeliefert.

## Lokal testen

1. Zwei Spielinstanzen öffnen, möglichst im Fenstermodus nebeneinander.
2. In A **Host erstellen**, in B **Lokal beitreten** klicken.
3. Auf `Verbunden` und steigende Paketzähler achten.
4. In beiden Fenstern einen Run im gleichen Biom starten.
5. Nahe dem Start bewegen und drehen. Im anderen Fenster sollte die türkise
   Figur mitfahren; die X/Z-Werte und Positionszähler sollten sich ändern.
6. Zum Wechseln **F8** bzw. die Maus-Schaltfläche im Mod-Fenster verwenden.
   Beim Zurückklicken ins Spiel endet die Mausfreigabe automatisch.
7. Beim Trennen oder Verlassen eines Runs verschwindet die Figur.

Die Weltgenerierung läuft noch getrennt. Gleiches Biom bedeutet hier nur eine
passende Spielszene für den Positionstest, keine gemeinsame Welt. Die Figur
kann weder kämpfen noch einsammeln oder Schaden nehmen.

## Spielstände und Entfernen

Der Testschutz blockiert die gefundenen `SaveLoad`-Schreib-, Backup-, Archiv-
und Resetmethoden. Beide Instanzen lesen weiter dasselbe Profil. Es sind keine
getrennten Profile und keine vollständige Dateisystem-Sandbox.

Einstellungen/PlayerPrefs, Steam-Achievements und andere Mods fallen nicht
unter den Schutz. Sichere das Profil vorher; normalerweise liegt es unter
`%USERPROFILE%/AppData/LocalLow/Randwerk/Wanderburg/`.
Das Build-Skript erstellt keine automatische Spielstand-Sicherung.

Für normales Spielen beide Instanzen schließen, ausschließlich
`BepInEx/plugins/WanderburgCoopTest.dll` entfernen und neu starten.
Spieldateien, Spielstände und andere Plugins behalten.

## Selbst bauen

Benötigt: .NET-10-SDK und lokale BepInEx-Interop-Dateien. Der Mod zielt auf .NET 6;
die reinen Netzwerkprüfungen laufen mit .NET 10 und benötigen kein Spiel.

```powershell
./build.ps1 -GameRoot 'D:/SteamLibrary/steamapps/common/Wanderburg Game'
```

Das Skript baut, testet und erzeugt unter `artifacts/` ein versioniertes ZIP mit
unserer DLL, beiden Anleitungen, Lizenz und Hinweisen. Es lädt nichts hoch und
ändert die Spielinstallation nicht.

## Geprüfter Stand

- Zwei 0.2-Spielinstanzen wurden erfolgreich lokal verbunden.
- Build 0.3.2: null Fehler, null Warnungen.
- **46 Netzwerk-/Protokollprüfungen** bestanden, darunter eine simulierte
  **6,5-sekündige Pause des Unity-Threads** und ein später startender Host.
- Start ohne Grafik: Version 0.3.2 und die Spielstand-/Fokus-Hooks laden.
- Der ursprüngliche Fokus-/Ladefehler und die sichtbare Figur sind nach dieser
  Korrektur noch im echten Spielablauf nachzuprüfen.

F8 kann mit Hotkeys anderer Mods kollidieren. Zunächst ohne weitere Mods testen.
Bei Fehlerberichten Versionen, genaue Schritte und relevante Logzeilen nennen;
persönliche Pfade entfernen. Keine vollständigen Spieldateien hochladen.

Unser Code steht unter [MIT](LICENSE). Rechte an Spiel, Marken und getrennt
installierten Abhängigkeiten bleiben bei deren Rechteinhabern.
Siehe [Drittanbieter-Hinweise](THIRD_PARTY_NOTICES.md).
