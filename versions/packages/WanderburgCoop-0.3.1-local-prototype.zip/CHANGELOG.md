# Changelog

## 0.3.1 — 2026-10-19

- Move socket ownership and heartbeat processing to a managed background thread.
- Keep connections alive during simulated Unity loading/focus stalls.
- Stop advertising frozen Unity samples as live players until sampling resumes.
- Re-assert background execution after the game's boot background override ends.
- Bypass focus-specific auto-pause decisions while the local test session is active.
- Add F8 cursor-release toggle; keep the toggle useful after failed joins.
- Disable Windows UDP port-unreachable reset notifications on the local socket.
- Add regression coverage for late hosts and a 6.5-second main-thread stall.
- Keep test save protection enabled. In-game focus/cursor retesting is pending.

## 0.3.0

- Two-way player position/yaw snapshots and cyan remote marker.
- Snapshot validation, sequence ordering, freshness and scene/run presence.
- Development-only SaveLoad write guard.

## 0.2.0

- Local host/client UI, UDP handshake, heartbeat and disconnect.
- Two real game instances connected successfully in manual testing.

## 0.1.0

- Minimal BepInEx IL2CPP startup plugin.
