using UnityEngine;

namespace WanderburgCoopTest;

// Main-thread only. Cache the rig on appearance changes; sample plain numeric
// poses after gameplay updates. The worker never receives a Unity reference.
internal sealed class VisualPoseSampler
{
    private VP source;
    private uint appearance;
    private List<VehicleModel.PoseSource> nodes;
    private bool limitLogged;

    public VisualPoseFrame Capture(VP vehicle, PlayerSnapshot snapshot)
    {
        if (!vehicle || !snapshot.InRun || snapshot.AppearanceId == 0)
        {
            source = null; nodes = null;
            return null;
        }
        if (source != vehicle || appearance != snapshot.AppearanceId || nodes == null)
        {
            source = vehicle;
            appearance = snapshot.AppearanceId;
            nodes = VehicleModel.GetPoseSources(vehicle);
            limitLogged = false;
        }
        if (nodes.Count > VisualPoseFrame.MaxNodes)
        {
            if (!limitLogged)
                BepInEx.Logging.Logger.CreateLogSource("Wanderburg Co-op Animation").LogWarning(
                    $"Rig has {nodes.Count} nodes; animation skipped above {VisualPoseFrame.MaxNodes} nodes.");
            limitLogged = true;
            return null;
        }
        var scale = vehicle.transform.lossyScale;
        if (Math.Abs(scale.x) < 0.000001f || Math.Abs(scale.y) < 0.000001f || Math.Abs(scale.z) < 0.000001f) return null;
        var poses = new VisualNodePose[nodes.Count];
        for (int i = 0; i < nodes.Count; i++)
        {
            var node = nodes[i];
            if (!node.Transform) { nodes = null; return null; }
            var t = node.Transform;
            Vector3 p = node.VehicleRelative ? vehicle.transform.InverseTransformPoint(t.position) : t.localPosition;
            Quaternion q = node.VehicleRelative ? Quaternion.Inverse(vehicle.transform.rotation) * t.rotation : t.localRotation;
            Vector3 s = node.VehicleRelative ? new Vector3(t.lossyScale.x / scale.x,
                t.lossyScale.y / scale.y, t.lossyScale.z / scale.z) : t.localScale;
            poses[i] = new VisualNodePose(node.Id, p.x, p.y, p.z, q.x, q.y, q.z, q.w, s.x, s.y, s.z);
        }
        var frame = new VisualPoseFrame(snapshot.Scene, snapshot.VehicleId, snapshot.AppearanceId, poses);
        return frame.IsValid ? frame : null;
    }
}
