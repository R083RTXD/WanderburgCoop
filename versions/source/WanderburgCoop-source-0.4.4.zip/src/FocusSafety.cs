namespace WanderburgCoopTest;

// Kept free of Unity references so the close-policy regression can be tested
// outside the game. Automatic focus transfer after a peer exits must not turn
// the peer's old click into permission to close this process.
public sealed class FocusCloseGate
{
    private bool readyForFocusedInput;

    public void OnFocusChanged(bool focused)
    {
        readyForFocusedInput = false;
    }

    public void Observe(bool applicationIsFocused, bool confirmationStartedThisFrame)
    {
        if (!applicationIsFocused)
        {
            readyForFocusedInput = false;
            return;
        }

        // A click that closes one window can be reported while Windows moves
        // focus to the surviving peer. Require one clean focused frame first.
        if (!readyForFocusedInput)
        {
            if (!confirmationStartedThisFrame) readyForFocusedInput = true;
            return;
        }
    }

    public bool TryConsumeClosePermission(bool applicationIsFocused, bool confirmationStartedThisFrame,
        bool peerLossSuppressionActive) =>
        !peerLossSuppressionActive && applicationIsFocused && readyForFocusedInput && confirmationStartedThisFrame;
}
