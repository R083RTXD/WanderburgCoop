# WanderburgCoop

Experimental local player-position prototype for **Wanderburg**.

[Deutsche Anleitung](README.de.md) · [Changelog](CHANGELOG.md) · [MIT license](LICENSE)

> **Development build 0.4.3 — this is not playable co-op yet.**
> Enemies, damage, loot, XP, upgrades and worlds are independent. Internet play,
> LAN discovery, invitation codes and Steam lobbies are not implemented.
> This build blocks the identified game-save write paths: test-run progress is
> not persisted. Remove the plugin before playing a run you want to keep.

An unofficial community project by **R083RTXD**, not affiliated with or endorsed
by Randwerk or the game's publisher. This repository contains original mod code;
it does not include game binaries, extracted assets or generated game assemblies.

## Current features

- Connect two instances on the **same Windows PC** using UDP `127.0.0.1:28714`.
- Negotiate a host-authoritative world seed and apply it before map generation.
- Exchange castle position and heading at up to 20 updates per second.
- Display the peer as a cyan, collision-free test marker with a heading indicator.
- Smooth marker movement; hide it on run exit, scene mismatch, stale data or disconnect.
- Run networking on a managed background thread, independent of Unity loading stalls.
- Prevent focus-loss auto-pause while the local test session is active.
- Press **F8** to release the cursor temporarily. Clicking back into the game
  restores the previous cursor state automatically.
- Preserve deliberate pauses and upgrade menus.
- Ignore quit-button clicks in an unfocused background instance; closing one
  peer only disconnects the other.

## Requirements

- A separately obtained Wanderburg installation. The development baseline is
  **0.9.14b, Windows x64, Unity 6000.0.63f1**. Other builds are unverified.
- **BepInEx 6 Unity IL2CPP Windows x64**. Development loader: `6.0.0-be.789`.
  BepInEx 5 and Unity Mono builds are not compatible.
- Both instances must use this version of the plugin. Do not mix old and new DLLs.

Follow the [official BepInEx IL2CPP installation guide](https://docs.bepinex.dev/master/articles/user_guide/installation/unity_il2cpp.html).
Install it next to the actual Unity executable, `UnityPlayer.dll` and
`GameAssembly.dll`. Some installations have an outer launcher and an inner game
folder: use the inner Unity folder. Start the game once to generate interop files.

## Install

1. Close every Wanderburg instance and back up your game profile.
2. Use the packaged `WanderburgCoopTest.dll`, or build it from source below.
3. Copy only that DLL into `BepInEx/plugins/` under the actual Unity game folder.
4. Restart both instances. The upper-right panel should say **0.4.3**.
5. Check `BepInEx/LogOutput.log` for `TEST SAVE GUARD ACTIVE` and the 0.4.3 load message.

This source repository is not an installer and does not include BepInEx or game files.
If GitHub Releases has no download yet, build the DLL locally; downloading the
source ZIP alone does not install the plugin.

## Test on one PC

1. Run two game instances, preferably side by side in windowed mode.
2. In A, click **Host erstellen** (create host).
3. In B, click **Lokal beitreten** (join locally).
4. Confirm `Verbunden` (connected), increasing packet counters and the same
   non-zero `Weltsamen` (world seed) in both panels.
5. Start a run in the same biome in both windows. Move and turn near the starting area.
6. Look for the cyan marker and changing local/remote X/Z coordinates.
7. Use **F8** or the panel button to release the cursor. When you click back
   into that game window, cursor release ends automatically.
8. Disconnect or leave a run: the peer's marker should disappear.

Version 0.4.3 asks Wanderburg's `MapGenerator` to use the same seed in both
instances. This is intended to produce matching map layouts, but still needs a
visible two-instance check. Enemies, combat, runtime randomness, loot and
progression are not synchronized. The marker cannot fight, collect resources
or take damage.

## Saves and settings

The test guard patches the identified `SaveLoad` write, backup, archive and reset
entrypoints and disables `writesEnabled`. If required hooks cannot be installed,
the connection component is not enabled. Both instances still read the same
existing profile: this is not separate profile storage or an OS sandbox.

PlayerPrefs/settings, Steam achievements and other mods are not covered. Back up
your profile before testing. Your normal profile is typically in
`%USERPROFILE%/AppData/LocalLow/Randwerk/Wanderburg/`. The source build script
does **not** back up or modify your game installation automatically.

## Uninstall

Close both instances, remove **only** `BepInEx/plugins/WanderburgCoopTest.dll`,
then restart. This restores the original save/focus behavior; no game binary is
patched on disk. Keep your saves and other plugins.

## Build, check and package

Install the .NET 10 SDK. The plugin targets .NET 6, as used by BepInEx, and the
transport test harness runs on .NET 10. A local game installation with generated
BepInEx interop assemblies is required to compile the plugin.

```powershell
./build.ps1 -GameRoot 'D:/SteamLibrary/steamapps/common/Wanderburg Game'
```

The script builds the plugin, runs the transport checks and creates a versioned
ZIP under `artifacts/` containing only our DLL, both guides, license and notices.
It does not upload, create a GitHub repository or install anything into the game.

Individual commands:

```powershell
dotnet build ./src/WanderburgCoopTest.csproj -c Release -p:WanderburgGameRoot='D:/SteamLibrary/steamapps/common/Wanderburg Game'
dotnet run --project ./tests/ConnectionChecks.csproj -c Release
```

The pure managed checks require no game installation. Do not commit generated
interop files, game files, save backups, logs or access tokens.

## Validation and known limits

- Two 0.2 game instances connected successfully in manual testing.
- Version 0.4.3 builds with zero errors and zero warnings.
- **52** transport/protocol and focus-policy checks pass, including shared-seed negotiation,
  late-host startup, packet
  validation, disconnect/reconnect and a **6.5-second simulated Unity stall**.
- Headless startup loaded 0.4.3 and installed the save/focus/world-seed hooks.
  Visible two-instance world-seed and peer-close behavior still need manual validation.
- The original in-game focus-loss/loading reproduction and visible marker still
  need manual rechecking after this fix. Headless startup does not validate rendering.
- Internet security, authentication, NAT traversal and relay fallback are absent.
  The loopback session token is not production authentication.
- F8 may conflict with another plugin's hotkey. Test without other mods first.
- Connecting after a biome has started is too late to apply the shared seed;
  connect in the main menu and only then start the same biome in both instances.

Please report game, BepInEx and plugin versions, exact steps and relevant log
lines. Remove personal paths before posting logs. Never upload your full game.

## License and third-party notices

Our original mod code is available under the [MIT license](LICENSE).
Game content, trademarks and separately installed dependencies are not covered
by this license. See [THIRD_PARTY_NOTICES.md](THIRD_PARTY_NOTICES.md).
