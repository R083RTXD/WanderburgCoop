# Changelog

## 0.4.3 — 2026-10-20

- Accept a fresh mouse-button release as the game's legitimate quit-button
  confirmation while retaining the focus-transfer and stale-input guards.
- Use the same confirmation definition when arming the clean-focus gate.

## 0.4.2 — 2026-10-20

- Do not retain close permission from an earlier mouse or keyboard input.
- Require the confirmation input to still be fresh when `CloseApplication` runs.
- Add a regression check for stale focused input after peer shutdown.

## 0.4.1 — 2026-10-20

- Require a fresh confirmation input from the focused process before allowing
  the game's `CloseApplication` path.
- Prevent automatic Windows focus transfer after a peer exits from reusing the
  departing peer's mouse click in the surviving instance.
- Preserve the shared world-seed protocol and position test from 0.4.0.

## 0.4.0 — 2026-10-20

- Add a host-authoritative world seed to local protocol `WB04`.
- Apply that seed before `MapGenerator.Awake` on both connected instances.
- Display the negotiated seed in the in-game test panel.
- Prevent an unfocused instance from processing another window's quit-button click.
- Require connection in the main menu before loading the biome for this test.
- Keep enemies, combat, loot and progression independent for now.

## 0.3.2 — 2026-10-20

- Make F8 cursor release an explicit temporary window-switching mode.
- Stop writing cursor state while the game window is unfocused.
- Automatically restore the previous cursor state when the game regains focus.
- Add focus-transition logging for manual crash verification.

## 0.3.1 — 2026-10-19

- Move socket ownership and heartbeat processing to a managed background thread.
- Keep connections alive during simulated Unity loading/focus stalls.
- Stop advertising frozen Unity samples as live players until sampling resumes.
- Re-assert background execution after the game's boot background override ends.
- Bypass focus-specific auto-pause decisions while the local test session is active.
- Add F8 cursor-release toggle; keep the toggle useful after failed joins.
- Disable Windows UDP port-unreachable reset notifications on the local socket.
- Add regression coverage for late hosts and a 6.5-second main-thread stall.
- Keep test save protection enabled. In-game focus/cursor retesting is pending.

## 0.3.0

- Two-way player position/yaw snapshots and cyan remote marker.
- Snapshot validation, sequence ordering, freshness and scene/run presence.
- Development-only SaveLoad write guard.

## 0.2.0

- Local host/client UI, UDP handshake, heartbeat and disconnect.
- Two real game instances connected successfully in manual testing.

## 0.1.0

- Minimal BepInEx IL2CPP startup plugin.
