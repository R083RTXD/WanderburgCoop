namespace WanderburgCoopTest;

// Kept free of Unity references so the close-policy regression can be tested
// outside the game. An unfocused instance must never react to another window's
// mouse click by closing itself.
public static class FocusSafety
{
    public static bool ShouldAllowApplicationClose(bool applicationIsFocused) => applicationIsFocused;
}
