using UnityEngine;
using Object = UnityEngine.Object;

namespace WanderburgCoopTest;

// Construct a render-only representation. Never Instantiate a VP/VM prefab:
// even temporarily disabled game components can execute Awake/OnEnable.
internal sealed class VehicleModel : IDisposable
{
    private readonly List<Mesh> bakedMeshes = new();
    private readonly Dictionary<int, Transform> transforms = new();
    private VP cachedSource;
    private float nextScan;
    private int catalogScene = int.MinValue;
    private static readonly BepInEx.Logging.ManualLogSource Log =
        BepInEx.Logging.Logger.CreateLogSource("Wanderburg Co-op Visual");

    public static uint GetIdentity(VP vehicle) => !vehicle ? 0 :
        VehicleIdentity.FromModuleId(string.IsNullOrEmpty(vehicle.moduleID)
            ? "prefab:" + vehicle.name.Replace("(Clone)", "").Trim()
            : vehicle.moduleID);

    public static uint GetAppearance(VP vehicle)
    {
        if (!vehicle) return 0;
        var parts = new List<string>();
        foreach (var filter in vehicle.GetComponentsInChildren<MeshFilter>(true))
        {
            var renderer = filter.GetComponent<MeshRenderer>();
            if (renderer && renderer.enabled && filter.sharedMesh && IsVisible(filter.transform, vehicle))
                parts.Add(DescribePart(renderer, filter.sharedMesh, vehicle));
        }
        foreach (var renderer in vehicle.GetComponentsInChildren<SkinnedMeshRenderer>(true))
            if (renderer.enabled && renderer.sharedMesh && IsVisible(renderer.transform, vehicle))
                parts.Add(DescribePart(renderer, renderer.sharedMesh, vehicle));
        return VehicleIdentity.FromAppearance(parts);
    }

    private static string DescribePart(Renderer renderer, Mesh mesh, VP vehicle)
    {
        var path = new List<string>();
        for (var node = renderer.transform; node && node != vehicle.transform; node = node.parent)
            path.Add(node.name);
        var materials = new List<string>();
        foreach (var material in renderer.sharedMaterials)
            materials.Add(material ? material.name.Replace(" (Instance)", "") : "none");
        return string.Join("/", path) + "|" + mesh.name + "|" + mesh.vertexCount + "|" +
            mesh.subMeshCount + "|" + string.Join(";", materials);
    }

    private static bool Matches(VP source, PlayerSnapshot remote) => source &&
        remote.AppearanceId != 0 && GetIdentity(source) == remote.VehicleId &&
        GetAppearance(source) == remote.AppearanceId;

    public bool TryBuild(GameObject destination, PlayerSnapshot remote)
    {
        if (remote.VehicleId == 0 || remote.AppearanceId == 0) return false;
        if (catalogScene != remote.Scene)
        {
            cachedSource = null;
            catalogScene = remote.Scene;
            nextScan = 0;
        }
        // A live same-appearance vehicle contains the body actually selected by
        // the player. A resident prefab may still contain its default body.
        var local = GM.gm && GM.gm.vm ? GM.gm.vm.vp : null;
        VP source = Matches(local, remote) ? local : Matches(cachedSource, remote) ? cachedSource : null;
        if (!source)
        {
            if (Time.unscaledTime < nextScan) return false;
            nextScan = Time.unscaledTime + 2;
            // Includes unloaded-from-scene but resident prefab assets. No
            // instantiation, unlock changes, or calls into vehicle gameplay.
            foreach (var candidate in Resources.FindObjectsOfTypeAll<VP>())
            {
                if (!candidate) continue;
                if (!Matches(candidate, remote)) continue;
                source = candidate;
                break;
            }
            if (!source) return false;
        }
        cachedSource = source;

        var visual = new GameObject("RemoteVehicle_VisualOnly");
        visual.transform.SetParent(destination.transform, false);
        visual.transform.localScale = source.transform.lossyScale;
        transforms.Clear();
        transforms[source.transform.GetInstanceID()] = visual.transform;
        int count = 0;
        foreach (var filter in source.GetComponentsInChildren<MeshFilter>(true))
        {
            var renderer = filter.GetComponent<MeshRenderer>();
            if (!renderer || !renderer.enabled || !filter.sharedMesh ||
                !IsVisible(filter.transform, source)) continue;
            Transform target = CopyTransform(filter.transform, source.transform);
            var meshFilter = target.gameObject.AddComponent<MeshFilter>();
            meshFilter.sharedMesh = filter.sharedMesh;
            var meshRenderer = target.gameObject.AddComponent<MeshRenderer>();
            meshRenderer.sharedMaterials = renderer.sharedMaterials;
            meshRenderer.shadowCastingMode = renderer.shadowCastingMode;
            meshRenderer.receiveShadows = renderer.receiveShadows;
            count++;
        }
        foreach (var renderer in source.GetComponentsInChildren<SkinnedMeshRenderer>(true))
        {
            if (!renderer.enabled || !renderer.sharedMesh ||
                !IsVisible(renderer.transform, source)) continue;
            var mesh = new Mesh();
            bakedMeshes.Add(mesh);
            renderer.BakeMesh(mesh);
            Transform target = CopyTransform(renderer.transform, source.transform);
            var filter = target.gameObject.AddComponent<MeshFilter>();
            filter.sharedMesh = mesh;
            var copy = target.gameObject.AddComponent<MeshRenderer>();
            copy.sharedMaterials = renderer.sharedMaterials;
            count++;
        }
        transforms.Clear();
        if (count == 0)
        {
            Object.Destroy(visual);
            return false;
        }
        Log.LogInfo($"PID {Environment.ProcessId}: visual vehicle {remote.VehicleId:X8}, appearance {remote.AppearanceId:X8}, {count} meshes from {source.name}, live={source.gameObject.scene.IsValid()}");
        return true;
    }

    private Transform CopyTransform(Transform source, Transform boundary)
    {
        int id = source.GetInstanceID();
        if (transforms.TryGetValue(id, out var result)) return result;
        var parent = CopyTransform(source.parent, boundary);
        var node = new GameObject(source.name) { layer = 2 }; // Ignore Raycast.
        result = node.transform;
        result.SetParent(parent, false);
        result.localPosition = source.localPosition;
        result.localRotation = source.localRotation;
        result.localScale = source.localScale;
        transforms[id] = result;
        return result;
    }

    private static bool IsVisible(Transform transform, VP source)
    {
        // Inspect actual render branches, not a skin-index mask applied to a
        // different prefab. Prefab assets have activeInHierarchy=false.
        for (var node = transform; node && node != source.transform; node = node.parent)
        {
            if (!node.gameObject.activeSelf) return false;
        }
        return true;
    }

    public void ClearMeshes()
    {
        foreach (var mesh in bakedMeshes) if (mesh) Object.Destroy(mesh);
        bakedMeshes.Clear();
        transforms.Clear();
    }

    public void Dispose()
    {
        ClearMeshes();
        cachedSource = null;
        catalogScene = int.MinValue;
        nextScan = 0;
    }
}
